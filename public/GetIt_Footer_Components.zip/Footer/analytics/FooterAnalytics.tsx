import React, { useEffect, useState, useCallback } from 'react';

interface FooterAnalyticsEvent {
  type: 'click' | 'hover' | 'view' | 'scroll';
  element: string;
  timestamp: number;
  metadata?: Record<string, any>;
}

interface FooterAnalyticsState {
  events: FooterAnalyticsEvent[];
  linkClicks: Record<string, number>;
  sectionViews: Record<string, number>;
  totalEngagement: number;
}

// Analytics service for footer interactions
class FooterAnalyticsService {
  private static instance: FooterAnalyticsService;
  private events: FooterAnalyticsEvent[] = [];
  private listeners: ((state: FooterAnalyticsState) => void)[] = [];

  static getInstance(): FooterAnalyticsService {
    if (!FooterAnalyticsService.instance) {
      FooterAnalyticsService.instance = new FooterAnalyticsService();
    }
    return FooterAnalyticsService.instance;
  }

  trackEvent(event: Omit<FooterAnalyticsEvent, 'timestamp'>): void {
    const fullEvent: FooterAnalyticsEvent = {
      ...event,
      timestamp: Date.now()
    };

    this.events.push(fullEvent);

    // Keep only last 1000 events for performance
    if (this.events.length > 1000) {
      this.events = this.events.slice(-1000);
    }

    this.notifyListeners();

    // Log to console in development
    if (process.env.NODE_ENV === 'development') {
      console.log('Footer Analytics Event:', fullEvent);
    }
  }

  subscribe(listener: (state: FooterAnalyticsState) => void): () => void {
    this.listeners.push(listener);
    
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  getAnalyticsState(): FooterAnalyticsState {
    const linkClicks: Record<string, number> = {};
    const sectionViews: Record<string, number> = {};

    this.events.forEach(event => {
      if (event.type === 'click') {
        linkClicks[event.element] = (linkClicks[event.element] || 0) + 1;
      }
      if (event.type === 'view') {
        sectionViews[event.element] = (sectionViews[event.element] || 0) + 1;
      }
    });

    return {
      events: [...this.events],
      linkClicks,
      sectionViews,
      totalEngagement: this.events.length
    };
  }

  private notifyListeners(): void {
    const state = this.getAnalyticsState();
    this.listeners.forEach(listener => listener(state));
  }

  // Export analytics for external systems
  exportAnalytics(): string {
    return JSON.stringify(this.getAnalyticsState(), null, 2);
  }

  // Clear analytics (useful for testing)
  clear(): void {
    this.events = [];
    this.notifyListeners();
  }
}

// React hook for footer analytics
export const useFooterAnalytics = () => {
  const [analyticsState, setAnalyticsState] = useState<FooterAnalyticsState>({
    events: [],
    linkClicks: {},
    sectionViews: {},
    totalEngagement: 0
  });

  useEffect(() => {
    const service = FooterAnalyticsService.getInstance();
    const unsubscribe = service.subscribe(setAnalyticsState);
    
    // Initialize state
    setAnalyticsState(service.getAnalyticsState());

    return unsubscribe;
  }, []);

  const trackClick = useCallback((element: string, metadata?: Record<string, any>) => {
    FooterAnalyticsService.getInstance().trackEvent({
      type: 'click',
      element,
      metadata
    });
  }, []);

  const trackHover = useCallback((element: string, metadata?: Record<string, any>) => {
    FooterAnalyticsService.getInstance().trackEvent({
      type: 'hover',
      element,
      metadata
    });
  }, []);

  const trackView = useCallback((element: string, metadata?: Record<string, any>) => {
    FooterAnalyticsService.getInstance().trackEvent({
      type: 'view',
      element,
      metadata
    });
  }, []);

  const trackScroll = useCallback((element: string, metadata?: Record<string, any>) => {
    FooterAnalyticsService.getInstance().trackEvent({
      type: 'scroll',
      element,
      metadata
    });
  }, []);

  return {
    analyticsState,
    trackClick,
    trackHover,
    trackView,
    trackScroll,
    exportAnalytics: () => FooterAnalyticsService.getInstance().exportAnalytics(),
    clearAnalytics: () => FooterAnalyticsService.getInstance().clear()
  };
};

// Analytics dashboard component (development only)
export const FooterAnalyticsDashboard: React.FC = () => {
  const { analyticsState, exportAnalytics, clearAnalytics } = useFooterAnalytics();

  if (process.env.NODE_ENV !== 'development') {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 bg-black bg-opacity-90 text-white p-4 rounded-lg text-xs max-w-xs z-50">
      <h3 className="font-bold mb-2">Footer Analytics</h3>
      <div className="space-y-1">
        <p>Total Events: {analyticsState.totalEngagement}</p>
        <p>Link Clicks: {Object.keys(analyticsState.linkClicks).length}</p>
        <p>Section Views: {Object.keys(analyticsState.sectionViews).length}</p>
      </div>
      
      <div className="mt-2 space-y-1">
        <h4 className="font-semibold">Top Clicked Links:</h4>
        {Object.entries(analyticsState.linkClicks)
          .sort(([,a], [,b]) => b - a)
          .slice(0, 3)
          .map(([link, count]) => (
            <p key={link} className="truncate">
              {link}: {count}
            </p>
          ))
        }
      </div>

      <div className="flex space-x-2 mt-3">
        <button 
          onClick={exportAnalytics}
          className="bg-blue-600 px-2 py-1 rounded text-xs hover:bg-blue-700"
        >
          Export
        </button>
        <button 
          onClick={clearAnalytics}
          className="bg-red-600 px-2 py-1 rounded text-xs hover:bg-red-700"
        >
          Clear
        </button>
      </div>
    </div>
  );
};

// Enhanced link component with analytics
interface AnalyticsLinkProps {
  to: string;
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  label?: string;
}

export const AnalyticsLink: React.FC<AnalyticsLinkProps> = ({
  to,
  children,
  className = '',
  onClick,
  label
}) => {
  const { trackClick, trackHover } = useFooterAnalytics();

  const handleClick = () => {
    trackClick(label || to, { url: to });
    onClick?.();
  };

  const handleMouseEnter = () => {
    trackHover(label || to, { url: to });
  };

  return (
    <a
      href={to}
      className={className}
      onClick={handleClick}
      onMouseEnter={handleMouseEnter}
    >
      {children}
    </a>
  );
};

export default FooterAnalyticsService;