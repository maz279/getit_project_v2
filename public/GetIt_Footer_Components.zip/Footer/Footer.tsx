import React from 'react';
import { FooterPerformanceOptimizer } from './performance/FooterPerformanceOptimizer';
import { FooterAnalyticsDashboard, useFooterAnalytics } from './analytics/FooterAnalytics';
import { GradientAnimation } from './animations/FooterAnimations';

// Legacy imports (kept for backwards compatibility)
import { FooterMainSection } from './footer/FooterMainSection';
import { FooterSecondarySection } from './footer/FooterSecondarySection';
import { FooterRegionalSection } from './footer/FooterRegionalSection';
import { FooterLegalSection } from './footer/FooterLegalSection';
import { FooterBusinessSection } from './footer/FooterBusinessSection';
import { FooterConnectSection } from './footer/FooterConnectSection';
import { FooterAdditionalServices } from './footer/FooterAdditionalServices';
import { FooterTechnologySection } from './footer/FooterTechnologySection';
import { FooterSpecialPrograms } from './footer/FooterSpecialPrograms';
import { FooterEmergencySupport } from './footer/FooterEmergencySupport';
import { FooterCopyright } from './footer/FooterCopyright';

interface FooterProps {
  className?: string;
  enablePerformanceOptimization?: boolean;
  enableAnalytics?: boolean;
  enableAnimations?: boolean;
}

export const Footer: React.FC<FooterProps> = ({ 
  className = '',
  enablePerformanceOptimization = true,
  enableAnalytics = true,
  enableAnimations = true
}) => {
  const { trackView } = useFooterAnalytics();

  React.useEffect(() => {
    if (enableAnalytics) {
      trackView('footer-load', { timestamp: Date.now() });
    }
  }, [enableAnalytics, trackView]);

  // Phase 4: Performance-optimized footer with lazy loading and analytics
  if (enablePerformanceOptimization) {
    return (
      <>
        <FooterPerformanceOptimizer 
          enableLazyLoading={true}
          enableAnimations={enableAnimations}
          enableProgressiveLoading={true}
        />
        {enableAnalytics && process.env.NODE_ENV === 'development' && (
          <FooterAnalyticsDashboard />
        )}
      </>
    );
  }

  // Legacy footer (for compatibility)
  return (
    <footer className={`bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 text-white mt-12 ${className}`}>
      <GradientAnimation>
        <div className="max-w-7xl mx-auto px-4 py-12">
          {/* Main Footer Section - 4 primary columns */}
          <FooterMainSection />

          {/* Secondary Footer Section - Payment, Shipping, Security */}
          <FooterSecondarySection />

          {/* Regional Information */}
          <FooterRegionalSection />

          {/* Legal & Compliance */}
          <FooterLegalSection />

          {/* Business Information */}
          <FooterBusinessSection />

          {/* Connect With Us */}
          <FooterConnectSection />

          {/* Additional Services */}
          <FooterAdditionalServices />

          {/* Technology & Innovation */}
          <FooterTechnologySection />

          {/* Special Programs */}
          <FooterSpecialPrograms />

          {/* Emergency & Support */}
          <FooterEmergencySupport />

          {/* Copyright */}
          <FooterCopyright />
        </div>
      </GradientAnimation>
      {enableAnalytics && process.env.NODE_ENV === 'development' && (
        <FooterAnalyticsDashboard />
      )}
    </footer>
  );
};